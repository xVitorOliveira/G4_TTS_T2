var speedo=1,voixo=1,modeONOFF=1;
var onoffH,voixoH,speedoH;
var getting  = browser.storage.sync.get("onoff") !== null ? browser.storage.sync.get("onoff") : null;
var getting2 = browser.storage.sync.get("speed") !== null ? browser.storage.sync.get("speed") : null;
var getting3 = browser.storage.sync.get("voix") !== null ? browser.storage.sync.get("voix") : null;

getting.then(onGot, onError);
getting2.then(onGot, onError);
getting3.then(onGot, onError);

function onError(error) {
     console.log(error);
}


function onGot(item) {
    console.log(item);
    if (item.onoff){
        modeONOFF = item.onoff;
        console.log(modeONOFF);
    }
    if (item.speed){
        speedo = item.speed;
        console.log(speedo);
    }
    if (item.voix){
        voixo = item.voix; 
        console.log(voixo);
    }
}

onoffH = document.getElementById(modeONOFF+"ONOFF");
console.log(onoffH);
onoffH.checked = true;
onoffH.style = "border : solid red 1px";
voixoH = document.getElementById(voixo+"V");
voixoH.checked = true;
speedoH = document.getElementById("speed");
speedoH.value = speedo;

